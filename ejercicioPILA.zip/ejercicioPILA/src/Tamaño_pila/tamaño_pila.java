
package Tamaño_pila;

public class tamaño_pila {
    public static void tamaño_pila(int B[]){
        for(int i=0;i<B.length;i++){
               B[i]=0;
           }  
            System.out.println("");
           for(int i=0;i<B.length;i++){
               System.out.println("["+B[i]+"]");
           }
           
    }
}
