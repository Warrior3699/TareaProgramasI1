package ejemarbol;

import java.util.Scanner;
import ejemarbol.Nodo;
public class Ejemarbol {

    public static void main(String[] args) {
        ArbolB A = new ArbolB();
        int indice;
        int opc;
        Scanner leer = new Scanner(System.in);
        System.out.println("\t****BIENVENIDO A ÁRBOL BINARIO ORDENADO****");
        do {
            System.out.println("\tMENÚ");
            System.out.println("\t1.Insertar");
            System.out.println("\t2.recorrer");
            System.out.println("\t3.Recorrido en Preorden");
            System.out.println("\t4.Recorrido en Inorden");
            System.out.println("\t5.Recorrido en Posorden");
            System.out.println("\t6.Buscar");
            System.out.println("\t7.Salir");
            System.out.println("\tseleccione opción >");
            opc = leer.nextInt();
            switch (opc) {
                case 1:
                    System.out.println("Dame el número a insertar\n");
                    int p = leer.nextInt();
                    A.InsertaNodo(p);
                    break;
                case 2:
                    System.out.println("Los elementos dentro son;");
                    A.recorrer(A.raiz);
                    break;
                case 3:
                    System.out.print("El recorrido en Preorden es: ");
                    A.Preorden(A.raiz);
                    System.out.println();
                    break;
                case 4:
                    System.out.print("El recorrido en Inorden es: ");
                    A.Inorden(A.raiz);
                    System.out.println();
                    break;
                case 5:
                    System.out.print("El recorrido en Postorden es: ");
                    A.PostOrden(A.raiz);
                    System.out.println();
                    break;
                case 6:
                    System.out.println("Buscar un valor");
                    System.out.println("Ingrese el valor a buscar");
                    indice = leer.nextInt();

                    A.Busqueda(indice, A.raiz);

                    break;
            }//fin switch
        } while (opc != 7);//fin do
    }

}
