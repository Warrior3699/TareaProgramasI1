package ejemarbol;

public class ArbolB {

   public Nodo padre;
    Nodo raiz;

    public ArbolB() {
        this.raiz = null;
    }

    public void InsertaNodo(int elem) {
        if (raiz == null) {
            raiz = new Nodo(elem);
        } else {
            raiz.InsertarBinario(elem);
        }

    }
     public void imprimir(){
        recorrer(raiz);
    }
    void recorrer(Nodo Nodo){
        if(Nodo != null){
            return;
        }else{
            recorrer(Nodo.izquierda);
            System.out.println(Nodo.getIzquierda()+"");
            recorrer(Nodo.derecha);
            System.out.println(Nodo.getDerecha()+"");
        }
    }

    public void Preorden(Nodo Nodo) {
        if (Nodo == null) {
            return;
        } else {
            System.out.println(Nodo.getElemento() + " ");
            Preorden(Nodo.getIzquierda());
            Preorden(Nodo.getDerecha());
        }
    }

    public void PostOrden(Nodo Nodo) {
        if (Nodo == null) {
            return;
        } else {
            PostOrden(Nodo.getIzquierda());
            PostOrden(Nodo.getDerecha());
            System.out.println(Nodo.getElemento() + "");
        }
    }

    public void Inorden(Nodo Nodo) {
        if (Nodo == null) {
            return;
        } else {
            Inorden(Nodo.getIzquierda());
            System.out.print(Nodo.getElemento() + " ");
            Inorden(Nodo.getDerecha());
        }
    }

    public void Busqueda(int Elem, Nodo A) {
        if ((A == null) | (A.getElemento() == Elem)) {
            System.out.print("el valor "+A.getElemento() + " si esta dentro. ");
            return;
        } else {
            if (Elem > A.getElemento()) {
                Busqueda(Elem, A.getDerecha());
            } else {
                Busqueda(Elem, A.getIzquierda());
            }
        }
    }

    public int Altura(Nodo Nodo) { // cuenta el número de niveles del árbol
        int Altder = (Nodo.getDerecha() == null ? 0 : 1 + Altura(Nodo.getDerecha()));
        int Altizq = (Nodo.getIzquierda() == null ? 0 : 1 + Altura(Nodo.getDerecha()));
        return Math.max(Altder, Altizq);
    }
}
