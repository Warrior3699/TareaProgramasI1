
package ejemarbol;

public class Nodo {
     int elemento;
     Nodo izquierda;
     Nodo derecha;

    public Nodo(int elemento) {
        this.elemento = elemento;
        this.izquierda = null;
        this.derecha = null;
    }
public void InsertarBinario(int elem){
    if(elem<this.elemento){
        if(izquierda==null)
            izquierda= new Nodo(elem);
        else
            izquierda.InsertarBinario(elem);
    }
    else{
        if(elem>this.elemento){
            if(derecha==null)
                derecha= new Nodo(elem);
            else
             derecha.InsertarBinario(elem);
        }
    }
}
    public int getElemento() {
        return elemento;
    }

    public void setElemento(int elemento) {
        this.elemento = elemento;
    }

    public Nodo getIzquierda() {
        return izquierda;
    }

    public void setIzquierda(Nodo izquierda) {
        this.izquierda = izquierda;
    }

    public Nodo getDerecha() {
        return derecha;
    }

    public void setDerecha(Nodo derecha) {
        this.derecha = derecha;
    }

    @Override
    public String toString() {
        return "Nodo{" + "elemento=" + elemento + ", izquierda=" + izquierda + ", derecha=" + derecha + '}';
    }

}
